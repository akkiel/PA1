Creators of this fine code:
Adam Kiel
Zac Schreck
